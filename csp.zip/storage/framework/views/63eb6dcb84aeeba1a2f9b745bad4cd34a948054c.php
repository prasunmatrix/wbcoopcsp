<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1>
        <?php echo e($page_title); ?>

    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo e(route('admin.block.list')); ?>"><i class="fa fa-home" aria-hidden="true"></i> Block List</a></li>
        <li class="active"><?php echo e($page_title); ?></li>
    </ol>
</section>

<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="box box-primary">
                <?php echo $__env->make('admin.elements.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
                <?php echo e(Form::open(array(
		                            'method'=> 'POST',
		                            'class' => '',
                                    'route' => ['admin.block.addSubmit'],
                                    'name'  => 'addCityForm',
                                    'id'    => 'addCityForm',
                                    'files' => true,
		                            'novalidate' => true))); ?>

                    <div class="box-body cus-body">
                        <div class="row">
                        <div class="col-md-6">
                                <div class="form-group">
                                <label for="title">District Name<span class="red_star">*</span></label>
                                    <select name="district_id" id="district_id" class="form-control" value="<?php echo e(old('district_id')); ?>" required>
                                        <option value="">-Select-</option>
                                <?php if(count($districtList)): ?>
                                    <?php $__currentLoopData = $districtList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($state->id); ?>" <?php if($state->id == old('district_id') ): ?> selected="selected" <?php endif; ?>><?php echo e($state->district_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name">Block Name<span class="red_star">*</span></label>
                                    <?php echo e(Form::text('block_name', null, array(
                                                                'id' => 'block_name',
                                                                'placeholder' => 'Name',
                                                                'class' => 'form-control',
                                                                'required' => 'required'
                                                                 ))); ?>

                                </div>
                            </div>
                            
                        </div>
                    </div>                        
                    <div class="box-footer">
                        <div class="col-md-6">
                            <button type="submit" class="btn btn-primary">Submit</button>
                            <a href="<?php echo e(route('admin.block.list')); ?>" class="btn btn-block btn-default btn_width_reset">Cancel</a>
                        </div>
                    </div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', ['title' => $panel_title], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wbstcbcspportal\resources\views/admin/block/add.blade.php ENDPATH**/ ?>