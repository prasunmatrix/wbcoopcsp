<?php
/*****************************************************/
# Role
# Page/Class name   : Role
# Author            :
# Created Date      : 27-05-2019
# Functionality     : Table declaration
# Purpose           : Table declaration
/*****************************************************/

namespace App;

use Illuminate\Database\Eloquent\Model;

class RolePage extends Model
{
    protected $table = 'role_pages';

    public $timestamps = false;
}