<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Societie extends Model
{
    protected $table = 'societies';

    public $timestamps = false;
}
